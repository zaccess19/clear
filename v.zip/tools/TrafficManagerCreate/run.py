import requests
import re

# Define your Azure AD token and API endpoint

token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ik1HTHFqOThWTkxvWGFGZnBKQ0JwZ0I0SmFLcyIsImtpZCI6Ik1HTHFqOThWTkxvWGFGZnBKQ0JwZ0I0SmFLcyJ9.eyJhdWQiOiJodHRwczovL21hbmFnZW1lbnQuYXp1cmUuY29tIiwiaXNzIjoiaHR0cHM6Ly9zdHMud2luZG93cy5uZXQvZjM2MjI1MGUtNjhlMS00N2M0LWEwNTQtYWRjZjI3NWZmMWU2LyIsImlhdCI6MTcyMDU2MzE4MSwibmJmIjoxNzIwNTYzMTgxLCJleHAiOjE3MjA1Njg1MjgsImFjciI6IjEiLCJhaW8iOiJBWVFBZS84WEFBQUF6U1JMRDhDM0ZHeXdqTUJac2RVMnN1dlBhQk5jaGQ1OVlHTXNTSmdxeUNqZXJMbS9pMTdOSzFneGtUTXdZYzlkdm5yZVBpZlAzWXJxanhXb3IxbldDK2YydWxROXEzMFZDN2VrODJUck9Hck90dDUwaURPQUNzM0RzSm15VmwxaW8zbFVaYVZ2NUQ3TlBHUFlUWEJQdEo2aFE0V0IwQXVPM29MMExnMEk1TFE9IiwiYWx0c2VjaWQiOiIxOmxpdmUuY29tOjAwMDM3RkZFN0E2NEMzRjciLCJhbXIiOlsicHdkIiwibWZhIl0sImFwcGlkIjoiMDRiMDc3OTUtOGRkYi00NjFhLWJiZWUtMDJmOWUxYmY3YjQ2IiwiYXBwaWRhY3IiOiIwIiwiZW1haWwiOiJpbmZvLmRkZXNrQGdtYWlsLmNvbSIsImZhbWlseV9uYW1lIjoiS3VtYXIiLCJnaXZlbl9uYW1lIjoiTWl0aHVuIiwiZ3JvdXBzIjpbImUxNTcyNzcwLTRmNWEtNDliNy04NzY0LThiNTFmYTQxM2MyZSJdLCJpZHAiOiJsaXZlLmNvbSIsImlkdHlwIjoidXNlciIsImlwYWRkciI6IjEwMy4yMTMuMzguMTAzIiwibmFtZSI6Ik1pdGh1biBLdW1hciIsIm9pZCI6Ijg2NzhhY2JhLTA2OGMtNGM2Yy05MWJjLWJiMmY4YmFmZGNlMCIsInB1aWQiOiIxMDAzMjAwMzY5QjkzNDA2IiwicmgiOiIwLkFTc0FEaVZpOC1Gb3hFZWdWSzNQSjFfeDVrWklmM2tBdXRkUHVrUGF3ZmoyTUJQQ0FPdy4iLCJzY3AiOiJ1c2VyX2ltcGVyc29uYXRpb24iLCJzdWIiOiJJaVRCcWpsLXViMzNRMU5YaFFqaHFydUh4MnEtNVZvT1NObFFxbW1iZldRIiwidGlkIjoiZjM2MjI1MGUtNjhlMS00N2M0LWEwNTQtYWRjZjI3NWZmMWU2IiwidW5pcXVlX25hbWUiOiJsaXZlLmNvbSNpbmZvLmRkZXNrQGdtYWlsLmNvbSIsInV0aSI6IklaTDRvU0hDOFU2UHQyWVlQNVBiQUEiLCJ2ZXIiOiIxLjAiLCJ3aWRzIjpbIjYyZTkwMzk0LTY5ZjUtNDIzNy05MTkwLTAxMjE3NzE0NWUxMCIsImI3OWZiZjRkLTNlZjktNDY4OS04MTQzLTc2YjE5NGU4NTUwOSJdLCJ4bXNfY2FlIjoiMSIsInhtc19jYyI6WyJDUDEiXSwieG1zX2Vkb3YiOnRydWUsInhtc19pZHJlbCI6IjEgOCIsInhtc190Y2R0IjoxNzExNzI3NTQ1fQ.YmUIbqToPbBUbB-gjjklqKbJ7vrgX2asesC7qiDNAGL8xcxvcVvn0o2GvmCRJlMK5B-HEU_3-wfvjveJcEBEWxc6aFhi-51C21mpkFVJha-a8bEYeJ6LT7AhVjg1HM01oFXulgrMkjjvpc-_zr02z1-wIL__VXo-jrmmKSk44_F4oLndxzGXUEgTGHSjGpnvJcu8ZShXTgM3pEN0TSNycUqEbfJJ7M6FORS-oiAhwosUgsPK0eISDS261QJEeSOvb46I0ORvK17BKujncKI6vC4q1vGnlkkCAaeQ5ABaAw3N73cI57AxZ72fp7r8bKjjMScoDY-AHAt2QQ6VEKUtsw"

management_endpoint = "https://management.azure.com"
subscription_id = "8c69b0e9-688f-4f3f-847c-75cad2e0337f"
group_name = "azure-tm-sisir"

# Define the file containing the profile names
input_file = "tm_profile_names.txt"

# Define the output file to save the results
output_file = "trafficmanager_results.txt"

# Read the text file and split it into lines
with open(input_file, "r") as file:
    profile_names = file.readlines()

# Define request headers
headers = {
    'Authorization': f'Bearer {token}',
    'Content-Type': 'application/json',
}


# Open the output file in write mode
with open(output_file, "w") as output:
    # Loop through the profile names and create profiles
    for profile_name in profile_names:
        profile_name = profile_name.strip()
        modified_profile_name = re.sub(r'[^a-zA-Z0-9-]', '', profile_name)
        # Define the API endpoint for creating the Traffic Manager profile
        endpoint = f"{management_endpoint}/subscriptions/{subscription_id}/resourceGroups/{group_name}/providers/Microsoft.Network/trafficManagerProfiles/{modified_profile_name}?api-version=2022-04-01"

        # Define the request body for creating the Traffic Manager profile
        request_body = {
            "location": "global",
            "tags": {},
            "properties": {
                "profileStatus": "Enabled",
                "trafficRoutingMethod": "Performance",
                "dnsConfig": {
                    "relativeName": profile_name,
                    "fqdn": f"{profile_name}.trafficmanager.net",
                },
                "monitorConfig": {
                    "profileMonitorStatus": "Online",
                    "protocol": "HTTP",
                    "port": 80,
                    "path": "/",
                    "intervalInSeconds": 30,
                    "timeoutInSeconds": 10,
                },
            },
        }

        # Send the HTTP request to create the Traffic Manager profile
        response = requests.put(endpoint, headers=headers, json=request_body)

        # Check the response status code
        if response.status_code == 201:
            print(f"\033[92mProfile '{profile_name}' created successfully.\033[0m")
            output.write(f"{profile_name}\tAvailable\n")
        else:
            print(f"Failed to create Azure Traffic Manager profile '{profile_name}'. Status Code: {response.status_code}. Response: {response.text}")
            output.write(f"{profile_name}\tNot Available\n")
