#!/bin/bash

# Define the domain list API And Project ID Here
input_file="vercel_list.txt"
API_Tokens="dGwM5CYlIRwjGzDTzuWwfLqS"
Projects_ID="prj_qGQjSp95mdQ88wDXjMNFL0dJDT6H"

# Read each domain from the input file
while IFS= read -r domain; do
    # Make the POST request to add the domain
    response=$(curl -s -X POST https://api.vercel.com/v9/projects/$Projects_ID/domains \
        -H "Authorization: Bearer $API_Tokens" \
        -H "Content-Type: application/json" \
        -d "{\"name\": \"$domain\"}")
    # Print the response
    echo "Response: $response"


    # Check the response for different cases
    if [[ $response == *"domain_already_in_use"* ]]; then
        echo -e "$domain\t\tNot Available" >> vercel_results.txt
    elif [[ $response == *"\"verified\":true"* ]]; then
        echo -e "$domain\t\tAvailable" >> vercel_results.txt
    elif [[ $response == *"pending_domain_verification"* ]]; then
        echo -e "$domain\t\tNot Available" >> vercel_results.txt
    else
        echo -e "$domain\t\tNot Available" >> vercel_results.txt
    fi

    # Check if the domain was added successfully and is pending verification
    if [[ $response == *"pending_domain_verification"* ]]; then
        sleep 1
        # Extract the domain name from the response
        apexName=$(echo "$response" | jq -r '.apexName')
        domain_to_delete=$(echo "$response" | jq -r '.name')

        # Delete the domain
        echo "Domain $domain_to_delete is pending verification. Deleting..."
        curl -X DELETE "https://api.vercel.com/v9/projects/$Projects_ID/domains/$domain_to_delete" \
            -H "Authorization: Bearer $API_Tokens"
    fi

done < "$input_file"
