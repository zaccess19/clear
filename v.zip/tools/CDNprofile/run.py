import requests

# Azure AD token for authentication

token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ik1HTHFqOThWTkxvWGFGZnBKQ0JwZ0I0SmFLcyIsImtpZCI6Ik1HTHFqOThWTkxvWGFGZnBKQ0JwZ0I0SmFLcyJ9.eyJhdWQiOiJodHRwczovL21hbmFnZW1lbnQuYXp1cmUuY29tIiwiaXNzIjoiaHR0cHM6Ly9zdHMud2luZG93cy5uZXQvZjM2MjI1MGUtNjhlMS00N2M0LWEwNTQtYWRjZjI3NWZmMWU2LyIsImlhdCI6MTcyMTI0NjMwMSwibmJmIjoxNzIxMjQ2MzAxLCJleHAiOjE3MjEyNTEwOTgsImFjciI6IjEiLCJhaW8iOiJBWVFBZS84WEFBQUFmVmZHM2dCMlpxU0pqQ0NjWTk4ZG9VNGpFZ3pDVlJGM0M2UGt4TS9mb3djcEpweW44UjNWV20xNmQySUdwSHEwa1pGT2JrYUc1UkpQNG14emJGa2tzYVZmbHBHV01oUE0zVGE5STh5VHM2bnZRb2phY3dsK2laOWE0enBpZDFyQ2d3b1llaHA4N01iMExKdGYzT01MY2hqRStaWk9GZjFnbWZBVnZBWFYzQkk9IiwiYWx0c2VjaWQiOiIxOmxpdmUuY29tOjAwMDM3RkZFN0E2NEMzRjciLCJhbXIiOlsicHdkIiwibWZhIl0sImFwcGlkIjoiMDRiMDc3OTUtOGRkYi00NjFhLWJiZWUtMDJmOWUxYmY3YjQ2IiwiYXBwaWRhY3IiOiIwIiwiZW1haWwiOiJpbmZvLmRkZXNrQGdtYWlsLmNvbSIsImZhbWlseV9uYW1lIjoiS3VtYXIiLCJnaXZlbl9uYW1lIjoiTWl0aHVuIiwiZ3JvdXBzIjpbImUxNTcyNzcwLTRmNWEtNDliNy04NzY0LThiNTFmYTQxM2MyZSJdLCJpZHAiOiJsaXZlLmNvbSIsImlkdHlwIjoidXNlciIsImlwYWRkciI6IjIwMy4yNi4xNTEuNTMiLCJuYW1lIjoiTWl0aHVuIEt1bWFyIiwib2lkIjoiODY3OGFjYmEtMDY4Yy00YzZjLTkxYmMtYmIyZjhiYWZkY2UwIiwicHVpZCI6IjEwMDMyMDAzNjlCOTM0MDYiLCJyaCI6IjAuQVNzQURpVmk4LUZveEVlZ1ZLM1BKMV94NWtaSWYza0F1dGRQdWtQYXdmajJNQlBDQU93LiIsInNjcCI6InVzZXJfaW1wZXJzb25hdGlvbiIsInN1YiI6IklpVEJxamwtdWIzM1ExTlhoUWpocXJ1SHgycS01Vm9PU05sUXFtbWJmV1EiLCJ0aWQiOiJmMzYyMjUwZS02OGUxLTQ3YzQtYTA1NC1hZGNmMjc1ZmYxZTYiLCJ1bmlxdWVfbmFtZSI6ImxpdmUuY29tI2luZm8uZGRlc2tAZ21haWwuY29tIiwidXRpIjoidE9UTDlaVUV3VXFsSDZna0lBTU5BQSIsInZlciI6IjEuMCIsIndpZHMiOlsiNjJlOTAzOTQtNjlmNS00MjM3LTkxOTAtMDEyMTc3MTQ1ZTEwIiwiYjc5ZmJmNGQtM2VmOS00Njg5LTgxNDMtNzZiMTk0ZTg1NTA5Il0sInhtc19jYWUiOiIxIiwieG1zX2NjIjpbIkNQMSJdLCJ4bXNfZWRvdiI6dHJ1ZSwieG1zX2lkcmVsIjoiMSA4IiwieG1zX3RjZHQiOjE3MTE3Mjc1NDV9.r1zZMFbgcScrLdnIAz_RbvgqObru8kZxvHFVoFABk1KbuvgTvrQd51Ac908fXscoKFYvA4P_kkUfYeKcMD4xOu6LLqIBnefq8FFfFjNfXU_vL8sqsQLeQx5Qq5SZnxFm51FFwuCxOopDnOzGDihs_xoSJxIj30We_mbusPF76b3jucxGGm8edc-_6fz05OQll6MGImcRSgWkAm-SWPYgd0Bi76BxtgqagYo4PKqQRvo9kDVboGVixMS9uk2FJVxa3j_zbS8VD2wA0BSrXZIugfBiZq4vAYYpEFdzcQhHZqazDyTlWfx-r-Ygas1vcwP4TtIN5w1hWAZGkkjB9Hz-lg"

# Azure Management endpoint
management_endpoint = "https://management.azure.com/providers/Microsoft.Cdn/checkNameAvailability?api-version=2024-02-01"

def check_cdn_profile_name_availability(cdn_profile_names):
    # Request headers
    headers = {
        'Authorization': f'Bearer {token}',
        'Content-Type': 'application/json'
    }

    for cdn_profile_name in cdn_profile_names:
        # Request body for each CDN Profile name
        request_body = {
            "name": cdn_profile_name,
            "type": "Microsoft.Cdn/Profiles/Endpoints"
        }

        # Send the HTTP request to check CDN Profile name availability
        response = requests.post(management_endpoint, headers=headers, json=request_body)

        # Check the response status code
        if response.status_code == 200:
            result = response.json()
            availability = result.get("nameAvailable")
            if availability:
                print("\033[92m" + f"{cdn_profile_name}\tAvailable" + "\033[0m")
                with open("cdnprofile_results.txt", "a") as file:
                    file.write(f"{cdn_profile_name}\tAvailable\n")
            else:
                print(f"{cdn_profile_name}\t is not available. Status Code: {response.status_code}. Response: {response.text}")
                with open("cdnprofile_results.txt", "a") as file:
                    file.write(f"{cdn_profile_name}\tNot Available\n")
        else:
            print(f"Failed to check CDN Profile name availability for '{cdn_profile_name}'. Status Code: {response.status_code}. Response: {response.text}")
            with open("cdnprofile_results.txt", "a") as file:
                file.write(f"{cdn_profile_name}\tNot Available\n")

 
# Function to read CDN Profile names from a text file
def read_cdn_profile_names_from_file(file_name):
    with open(file_name, "r") as file:
        cdn_profile_names = [line.strip() for line in file.readlines() if line.strip()]
    return cdn_profile_names

# Example text file containing CDN Profile names
file_name = "cdn_profile_names.txt"

# Read CDN Profile names from the text file
cdn_profile_names = read_cdn_profile_names_from_file(file_name)

# Call the function to check availability for each name
check_cdn_profile_name_availability(cdn_profile_names)
