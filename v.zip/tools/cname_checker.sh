#!/bin/bash

# Check if input file provided
if [ $# -eq 0 ]; then
    echo "Usage: $0 <input_file>"
    exit 1
fi

input_file=$1
output_file="tmp1.txt"

# Check if input file exists
if [ ! -f "$input_file" ]; then
    echo "Input file not found!"
    exit 1
fi

dos2unix -q $1

# Clear previous content of the output file
> "$output_file"

# Loop through each domain in the input file
while IFS= read -r domain; do
    cnames=$(dig +short cname $domain)
    if [ -z "$cnames" ]; then
        echo "$domain No CNAME record found"
		echo "$domain No-CNAME-found" >> "$output_file"
    else
        # Replace spaces with commas
        cnames=$(echo "$cnames" | tr '' ',')
        echo "$domain $cnames"
		echo "$domain $cnames" >> "$output_file"
    fi
done < "$input_file"

sed -i 's/\.$//g' $output_file
cat $output_file | grep azurefd[.]net > azurefd.txt
cat $output_file | grep azureedge[.]net > azureedge1.txt
rm $output_file
