#!/bin/bash

# Define API key and pull zone ID
API_KEY="0f4551f0-a2a8-47d4-b79f-a7e105e9d62d0928fae5-4ffd-4474-9466-f123a78ce76c"
PULL_ZONE_ID="2296832"
ORIGIN_URL="http://154.41.230.21"
SSL_TYPE="shared"

# Function to add a hostname using curl
add_hostname() {
    hostname="$1"
    response=$(curl -s -X POST \
        -H "AccessKey: $API_KEY" \
        -H "Content-Type: application/json" \
        -d "{\"PullZoneID\": \"$PULL_ZONE_ID\", \"Hostname\": \"$hostname\", \"OriginURL\": \"$ORIGIN_URL\", \"ForceSSL\": true, \"SSLType\": \"$SSL_TYPE\"}" \
        https://bunnycdn.com/api/pullzone/addHostname)

    # Check for specific error message
    error_key=$(echo "$response" | jq -r '.ErrorKey')

    if [[ "$error_key" == "pullzone.hostname_already_registered" ]]; then
        echo -e "$hostname\tNot available" | tee -a bunny_results.txt
    else
        echo -e "$hostname\tAvailable" | tee -a bunny_results.txt
    fi
}

# Read hostnames from file and add each one
while IFS= read -r hostname; do
    add_hostname "$hostname"
    sleep 1
done < bunny_list.txt
