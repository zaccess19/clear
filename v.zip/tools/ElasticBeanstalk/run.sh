#!/bin/bash

# Assuming the file containing DNS names and regions is named "elasticbeanstalk_dns_list.txt"
input_file="elasticbeanstalk_dns_list.txt"

# Output file to save the results
output_file="elasticbeanstalk_results.txt"

# Loop through each line in the input file
while IFS=$' ' read -r dns_name region; do
    # Check DNS availability for the current DNS name and region
    result=$(aws elasticbeanstalk check-dns-availability --cname-prefix "$dns_name" --region "$region" --output text)

    # Check if the result contains "True" or "False"
    if [[ "$result" == *"True"* ]]; then
        echo "DNS name: $dns_name | Region: $region | Result: DNS available"
        echo -e "$dns_name\tAvailable" >> "$output_file"
    else
        echo "DNS name: $dns_name | Region: $region | Result: DNS not available"
        echo -e "$dns_name\tNot Available" >> "$output_file"
    fi
done < "$input_file"
