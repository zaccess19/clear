import requests

# Azure AD token for authentication

token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ik1HTHFqOThWTkxvWGFGZnBKQ0JwZ0I0SmFLcyIsImtpZCI6Ik1HTHFqOThWTkxvWGFGZnBKQ0JwZ0I0SmFLcyJ9.eyJhdWQiOiJodHRwczovL21hbmFnZW1lbnQuYXp1cmUuY29tIiwiaXNzIjoiaHR0cHM6Ly9zdHMud2luZG93cy5uZXQvZjM2MjI1MGUtNjhlMS00N2M0LWEwNTQtYWRjZjI3NWZmMWU2LyIsImlhdCI6MTcyMTI1OTYwMCwibmJmIjoxNzIxMjU5NjAwLCJleHAiOjE3MjEyNjQ2MTAsImFjciI6IjEiLCJhaW8iOiJBWVFBZS84WEFBQUE3NjlpaW5TZ0tDUTdwSVZqajRWbUxmMHhyYWtEcGdOWkY4TVVpenVDQWdscUwxUTZMMFdhOGpZVmdwcXlTdEpDRkFyOHg3MlJrY1VHamJZNU41S3VLUEl0bHpBREtWWDFkbXlmbXdrRC9ieDFWQmNGMmRndndpU3ZkZHMybHpPN0xnVG9TOFdlSURrYzdML2h2elROUENwb085UWprbDdYRjBuTEI0QkVtWGc9IiwiYWx0c2VjaWQiOiIxOmxpdmUuY29tOjAwMDM3RkZFN0E2NEMzRjciLCJhbXIiOlsicHdkIiwibWZhIl0sImFwcGlkIjoiMDRiMDc3OTUtOGRkYi00NjFhLWJiZWUtMDJmOWUxYmY3YjQ2IiwiYXBwaWRhY3IiOiIwIiwiZW1haWwiOiJpbmZvLmRkZXNrQGdtYWlsLmNvbSIsImZhbWlseV9uYW1lIjoiS3VtYXIiLCJnaXZlbl9uYW1lIjoiTWl0aHVuIiwiZ3JvdXBzIjpbImUxNTcyNzcwLTRmNWEtNDliNy04NzY0LThiNTFmYTQxM2MyZSJdLCJpZHAiOiJsaXZlLmNvbSIsImlkdHlwIjoidXNlciIsImlwYWRkciI6IjIwMy4yNi4xNTEuNTMiLCJuYW1lIjoiTWl0aHVuIEt1bWFyIiwib2lkIjoiODY3OGFjYmEtMDY4Yy00YzZjLTkxYmMtYmIyZjhiYWZkY2UwIiwicHVpZCI6IjEwMDMyMDAzNjlCOTM0MDYiLCJyaCI6IjAuQVNzQURpVmk4LUZveEVlZ1ZLM1BKMV94NWtaSWYza0F1dGRQdWtQYXdmajJNQlBDQU93LiIsInNjcCI6InVzZXJfaW1wZXJzb25hdGlvbiIsInN1YiI6IklpVEJxamwtdWIzM1ExTlhoUWpocXJ1SHgycS01Vm9PU05sUXFtbWJmV1EiLCJ0aWQiOiJmMzYyMjUwZS02OGUxLTQ3YzQtYTA1NC1hZGNmMjc1ZmYxZTYiLCJ1bmlxdWVfbmFtZSI6ImxpdmUuY29tI2luZm8uZGRlc2tAZ21haWwuY29tIiwidXRpIjoiVVpXMTlRVmw2VXlObXFjcnNQWURBQSIsInZlciI6IjEuMCIsIndpZHMiOlsiNjJlOTAzOTQtNjlmNS00MjM3LTkxOTAtMDEyMTc3MTQ1ZTEwIiwiYjc5ZmJmNGQtM2VmOS00Njg5LTgxNDMtNzZiMTk0ZTg1NTA5Il0sInhtc19jYWUiOiIxIiwieG1zX2NjIjpbIkNQMSJdLCJ4bXNfZWRvdiI6dHJ1ZSwieG1zX2lkcmVsIjoiMSAyMiIsInhtc190Y2R0IjoxNzExNzI3NTQ1fQ.P6-KNWUqfzrXNlCD5c88gKsITmuZzP_88r-0W3lsjXj6TXTUkfSFFEX3asOdOq0TdU1VymSTAaoHt2NGDpw0eCZnwgyhlg0gTL0-wLxLk9VsFKGaU61MCZJq5Q5NXNyyLFeqoXXykKKUqscQ7x_Ayg44RdWAwCd5vLlG6lfjYnxwUS3HDtss6h4JYucR4CWqWxsvDJccwLUrZlnkiEZihMxx0I1XgucRwI7kvvSrOYjU4Aj7Fe_Q1N1TvWIu6H8ZoBEhbaGJkvQuurvjai2IAol8zUTCsqgMa3m1GQX7fQobtW7tDuomo5iXRfWOTu8tkYZbN1Obygic8HlnBKUDZA"

subscription_id = "8c69b0e9-688f-4f3f-847c-75cad2e0337f"

# Azure Management endpoint
management_endpoint = f"https://management.azure.com/subscriptions/{subscription_id}/providers/Microsoft.Web/checkNameAvailability?api-version=2023-12-01"

def check_web_app_name_availability(web_app_names):
    with open("webapp_results.txt", "w") as file:
        # Request headers
        headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        }

        # Iterate through each web app name
        for web_app_name in web_app_names:
            # Request body for each web app name
            request_body = {
                "name": web_app_name,
                "type": "Microsoft.Web/sites"
            }

            # Send the HTTP request to check web app name availability
            response = requests.post(management_endpoint, headers=headers, json=request_body)

            # Check the response status code
            if response.status_code == 200:
                result = response.json()
                availability = result.get("nameAvailable")
                if availability:
                    print(f"\033[92mProfile '{web_app_name}' is Available. Status Code: {response.status_code}. Response: {response.text}\033[0m")
                    file.write(f"{web_app_name}\tAvailable\n")
                else:
                    print(f"'{web_app_name}'. Status Code: {response.status_code}. Response: {response.text}")
                    file.write(f"{web_app_name}\tNot Available\n")
            else:
                print(f"'{web_app_name}'. Status Code: {response.status_code}. Response: {response.text}")
                file.write(f"{web_app_name}\tNot Available\n")

# Function to read web app names from a text file
def read_web_app_names_from_file(file_name):
    with open(file_name, "r") as file:
        web_app_names = [line.strip() for line in file.readlines() if line.strip()]
    return web_app_names

# Example text file containing web app names
file_name = "web_app_names.txt"

# Read web app names from the text file
web_app_names = read_web_app_names_from_file(file_name)

# Call the function to check availability for each name
check_web_app_name_availability(web_app_names)
