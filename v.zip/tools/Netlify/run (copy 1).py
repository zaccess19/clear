import requests
import time

API_TOKEN = 'nfp_2gsA8sEt77d5MM4wrhUb5bQKp9AgWpXG186e'
SITE_ID = '66fed78f-2d7c-4ca0-b099-70ceea95c7a0'
api_url = f'https://api.netlify.com/api/v1/sites/{SITE_ID}'

with open('netlify.txt', 'r') as file:
    domains = file.readlines()

headers = {
    'Authorization': f'Bearer {API_TOKEN}',
    'Content-Type': 'application/json'
}

with open('netlify_results.txt', 'w') as output_file:
    for domain in domains:
        payload = {'custom_domain': domain.strip()}  # Strip newline characters from the domain
        response = requests.put(api_url, headers=headers, json=payload)
        
        while response.status_code == 422 and "We're provisioning a certificate for your site" in response.json().get('message', ''):
            print(f"Failed to add domain '{domain}': Provisioning certificate in progress. Retrying in 10 seconds...")
            time.sleep(10)
            response = requests.put(api_url, headers=headers, json=payload)
        
        if response.status_code == 200:
            print(f"\033[92m'{domain.strip()}' Is Available to add on Netlify\033[0m")
            output_file.write(f"{domain.strip()}\t\tAvailable\n")
        else:
            print(f"Failed to add domain '{domain.strip()}': {response.json().get('message', 'Unknown error')}")
            output_file.write(f"{domain.strip()}\t\tNot Available\n")
