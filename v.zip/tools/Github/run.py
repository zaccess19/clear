import subprocess

# Read domains from file.txt
with open('github.txt', 'r') as file:
    domains = [line.strip() for line in file.readlines()]

# Open output file for writing
with open('github_results.txt', 'w') as output_file:
    for domain in domains:
        # Check if the domain can be added
        command = f"gh api repos/useveryone/Suspended/pages -X PUT -F cname='{domain}'"
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        
        if result.returncode == 0:
            print(f"\033[92m{domain} Is Available to add on Github Repo\033[0m")
            output_file.write(f"{domain}\t\tAvailable\n")
        else:
            print(f"{domain} Not Available to add on Github Repo")
            output_file.write(f"{domain}\t\tNot Available\n")

