import requests

def check_dns_name_availability(subscription_id, location, domain_name_label, api_version, token):
    url = f"https://management.azure.com/subscriptions/{subscription_id}/providers/Microsoft.Network/locations/{location}/CheckDnsNameAvailability?api-version={api_version}&domainNameLabel={domain_name_label}"
    
    headers = {
        "Authorization": f"Bearer {token}"
    }

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        availability = response.json()
        return availability
    else:
        return {"error": response.text}

if __name__ == "__main__":
    subscription_id = "8c69b0e9-688f-4f3f-847c-75cad2e0337f"
    api_version = "2023-11-01"

    token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ik1HTHFqOThWTkxvWGFGZnBKQ0JwZ0I0SmFLcyIsImtpZCI6Ik1HTHFqOThWTkxvWGFGZnBKQ0JwZ0I0SmFLcyJ9.eyJhdWQiOiJodHRwczovL21hbmFnZW1lbnQuYXp1cmUuY29tIiwiaXNzIjoiaHR0cHM6Ly9zdHMud2luZG93cy5uZXQvZjM2MjI1MGUtNjhlMS00N2M0LWEwNTQtYWRjZjI3NWZmMWU2LyIsImlhdCI6MTcyMTI0NjMwMSwibmJmIjoxNzIxMjQ2MzAxLCJleHAiOjE3MjEyNTEwOTgsImFjciI6IjEiLCJhaW8iOiJBWVFBZS84WEFBQUFmVmZHM2dCMlpxU0pqQ0NjWTk4ZG9VNGpFZ3pDVlJGM0M2UGt4TS9mb3djcEpweW44UjNWV20xNmQySUdwSHEwa1pGT2JrYUc1UkpQNG14emJGa2tzYVZmbHBHV01oUE0zVGE5STh5VHM2bnZRb2phY3dsK2laOWE0enBpZDFyQ2d3b1llaHA4N01iMExKdGYzT01MY2hqRStaWk9GZjFnbWZBVnZBWFYzQkk9IiwiYWx0c2VjaWQiOiIxOmxpdmUuY29tOjAwMDM3RkZFN0E2NEMzRjciLCJhbXIiOlsicHdkIiwibWZhIl0sImFwcGlkIjoiMDRiMDc3OTUtOGRkYi00NjFhLWJiZWUtMDJmOWUxYmY3YjQ2IiwiYXBwaWRhY3IiOiIwIiwiZW1haWwiOiJpbmZvLmRkZXNrQGdtYWlsLmNvbSIsImZhbWlseV9uYW1lIjoiS3VtYXIiLCJnaXZlbl9uYW1lIjoiTWl0aHVuIiwiZ3JvdXBzIjpbImUxNTcyNzcwLTRmNWEtNDliNy04NzY0LThiNTFmYTQxM2MyZSJdLCJpZHAiOiJsaXZlLmNvbSIsImlkdHlwIjoidXNlciIsImlwYWRkciI6IjIwMy4yNi4xNTEuNTMiLCJuYW1lIjoiTWl0aHVuIEt1bWFyIiwib2lkIjoiODY3OGFjYmEtMDY4Yy00YzZjLTkxYmMtYmIyZjhiYWZkY2UwIiwicHVpZCI6IjEwMDMyMDAzNjlCOTM0MDYiLCJyaCI6IjAuQVNzQURpVmk4LUZveEVlZ1ZLM1BKMV94NWtaSWYza0F1dGRQdWtQYXdmajJNQlBDQU93LiIsInNjcCI6InVzZXJfaW1wZXJzb25hdGlvbiIsInN1YiI6IklpVEJxamwtdWIzM1ExTlhoUWpocXJ1SHgycS01Vm9PU05sUXFtbWJmV1EiLCJ0aWQiOiJmMzYyMjUwZS02OGUxLTQ3YzQtYTA1NC1hZGNmMjc1ZmYxZTYiLCJ1bmlxdWVfbmFtZSI6ImxpdmUuY29tI2luZm8uZGRlc2tAZ21haWwuY29tIiwidXRpIjoidE9UTDlaVUV3VXFsSDZna0lBTU5BQSIsInZlciI6IjEuMCIsIndpZHMiOlsiNjJlOTAzOTQtNjlmNS00MjM3LTkxOTAtMDEyMTc3MTQ1ZTEwIiwiYjc5ZmJmNGQtM2VmOS00Njg5LTgxNDMtNzZiMTk0ZTg1NTA5Il0sInhtc19jYWUiOiIxIiwieG1zX2NjIjpbIkNQMSJdLCJ4bXNfZWRvdiI6dHJ1ZSwieG1zX2lkcmVsIjoiMSA4IiwieG1zX3RjZHQiOjE3MTE3Mjc1NDV9.r1zZMFbgcScrLdnIAz_RbvgqObru8kZxvHFVoFABk1KbuvgTvrQd51Ac908fXscoKFYvA4P_kkUfYeKcMD4xOu6LLqIBnefq8FFfFjNfXU_vL8sqsQLeQx5Qq5SZnxFm51FFwuCxOopDnOzGDihs_xoSJxIj30We_mbusPF76b3jucxGGm8edc-_6fz05OQll6MGImcRSgWkAm-SWPYgd0Bi76BxtgqagYo4PKqQRvo9kDVboGVixMS9uk2FJVxa3j_zbS8VD2wA0BSrXZIugfBiZq4vAYYpEFdzcQhHZqazDyTlWfx-r-Ygas1vcwP4TtIN5w1hWAZGkkjB9Hz-lg"

    # cloudapp_domains_locations.txt must contain domain name [tab] location
    with open("cloudapp_domains_locations.txt", "r") as file:
        domain_location_pairs = [line.strip().split("\t") for line in file]

    with open("cloudappdns_results.txt", "w") as result_file:
        for domain_name, location in domain_location_pairs:
            availability = check_dns_name_availability(subscription_id, location, domain_name, api_version, token)
#            print(f"Domain Name: {domain_name}, Location: {location}, Availability: {availability}")
            if availability.get('available', False):
                print(f"\033[92mDomain Name: {domain_name}, Location: {location}, Availability: {availability}\033[0m")
                result_file.write(f"{domain_name}\tAvailable\n")
            else:
                print(f"Domain Name: {domain_name}, Location: {location}, Availability: {availability}")
                result_file.write(f"{domain_name}\tNot Available\n")
