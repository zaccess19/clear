#!/bin/bash

if [ "$#" -ne 1 ]; then
    echo "Usage: $0 <filename>"
    exit 1
fi


DATE=`date +%Y-%m-%d`
if [ -e final_results.txt ]
  then
     if ! grep -q $DATE s3.txt
       then
       printdate=$DATE
       echo "============ $printdate ============" >> final_results.txt
     fi
fi




file="$1"

cat "$file" | sed 's/\x1B\[[0-9;]*[mGK]//g' | sed 's/\[//g; s/\]//g; s/,//g; s/"//g' | tr '[:upper:]' '[:lower:]' | sed 's/https:\/\///g; s/http:\/\///g' > tmp && mv tmp "$file"


cat "$file" | grep elasticbeanstalk-takeover | cut -d' ' -f4- | awk '$2 ~ /elasticbeanstalk\.com/' >> elasticbeanstalk.txt
cat elasticbeanstalk.txt | cut -d' ' -f2 | sed 's/.elasticbeanstalk.com//g' | sed 's/\.\([^\.]*\)$/ \1/' > elasticbeanstalk_dns_list.txt
dos2unix -q elasticbeanstalk_dns_list.txt

cat "$file" | grep azurewebsites[.]net | cut -d' ' -f4- | awk '$2 ~ /azurewebsites\.net/' >> azurewebsites.txt
cat azurewebsites.txt | cut -d' ' -f2 | sed 's/.azurewebsites.net//g' > web_app_names.txt

cat "$file" | grep cloudapp[.]azure[.]com | cut -d' ' -f4- | awk '$2 ~ /cloudapp\.azure\.com/' | grep -Ev '[/\\()\[]' > cloudapp.txt
cat cloudapp.txt | cut -d' ' -f2 | sed 's/.cloudapp.azure.com//g' | sed 's/\.\([^\.]*\)$/ \1/' | awk '$2 != ""' | tr ' ' '\t' > cloudapp_domains_locations.txt

cat "$file" | grep trafficmanager[.]net | cut -d' ' -f4- | awk '$2 ~ /trafficmanager\.net/' | cut -d' ' -f1,2 | awk '$2 ~ /trafficmanager\.net/' >> trafficmanager.txt
cat trafficmanager.txt | cut -d' ' -f2 | sed 's/.trafficmanager.net//g' > tm_profile_names.txt

cat "$file" | grep azurefd-takeover | cut -d' ' -f4- >> azurefd.txt
sh tools/cname_checker.sh azurefd.txt
cat azurefd.txt | cut -d' ' -f2 | sed 's/.azurefd.net//g' > front_door_names.txt

cat "$file" | grep azureedge[.]net | cut -d' ' -f4- | awk '$2 ~ /azureedge\.net/' >> azureedge.txt
cat azureedge1.txt >> azureedge.txt && rm azureedge1.txt
cat azureedge.txt | cut -d' ' -f2 | sed 's/.azureedge.net//g' > cdn_profile_names.txt

cat "$file" | grep netlify-takeover | cut -d' ' -f4- >> netlify.txt

cat "$file" | grep github-takeover | cut -d' ' -f4- >> github.txt

cat "$file" | grep aws-bucket-takeover | cut -d' ' -f4 >> s3.txt

cat "$file" | grep -a bunny-takeover | cut -d' ' -f4 >> bunny_list.txt

cat "$file" | grep -a vercel-takeover | cut -d' ' -f4 >> vercel_list.txt


source /azcli-env/bin/activate


  if [ -s "azureedge.txt" ]; then
    echo -e "\033[1;33mChecking Azure CDN Profile Availability.\033[0m" && sleep 2
    access_token=$(az account get-access-token --resource https://management.azure.com | jq -r '.accessToken')
      sed -E -i "s/token = \"[^\"]+\"/token = \"$access_token\"/g" tools/CDNprofile/run.py
        python tools/CDNprofile/run.py

	  cat azureedge.txt | sed 's/ /\t/g' > tm6 && mv tm6 azureedge.txt
          dos2unix -q azureedge.txt cdnprofile_results.txt
	  paste azureedge.txt <(cut -f2 cdnprofile_results.txt) >> final_cdnprofile_results.txt && rm azureedge.txt cdn_profile_names.txt cdnprofile_results.txt
	  sed -i 's/^/Azure CDN Profile\t/' final_cdnprofile_results.txt
	  cat final_cdnprofile_results.txt >> final_results.txt && rm final_cdnprofile_results.txt
    else
      rm azureedge.txt cdn_profile_names.txt
  fi

  if [ -s "cloudapp.txt" ]; then
    echo -e "\033[1;33mChecking Azure Cloud App Availability.\033[0m" && sleep 2
    access_token=$(az account get-access-token --resource https://management.azure.com | jq -r '.accessToken')
      sed -E -i "s/token = \"[^\"]+\"/token = \"$access_token\"/g" tools/CloudAppDns/run.py
        python tools/CloudAppDns/run.py

	  cat cloudapp.txt | sed 's/ /\t/g' > tm3 && mv tm3 cloudapp.txt
          dos2unix -q cloudapp.txt cloudappdns_results.txt
	  paste cloudapp.txt <(cut -f2 cloudappdns_results.txt) >> final_cloudappdns_results.txt && rm cloudapp.txt cloudapp_domains_locations.txt cloudappdns_results.txt
	  sed -i 's/^/Azure Cloud App\t/' final_cloudappdns_results.txt
	  cat final_cloudappdns_results.txt >> final_results.txt && rm final_cloudappdns_results.txt
    else
      rm cloudapp.txt cloudapp_domains_locations.txt
  fi

  if [ -s "azurefd.txt" ]; then
    echo -e "\033[1;33mChecking Azure Front Door Availability.\033[0m" && sleep 2
    access_token=$(az account get-access-token --resource https://management.azure.com | jq -r '.accessToken')
      sed -E -i "s/token = \"[^\"]+\"/token = \"$access_token\"/g" tools/FrontDoor/run.py
        python tools/FrontDoor/run.py

	  cat azurefd.txt | sed 's/ /\t/g' > tm2 && mv tm2 azurefd.txt
          dos2unix -q azurefd.txt frontdoor_results.txt
	  paste azurefd.txt <(cut -f2 frontdoor_results.txt) >> final_frontdoor_results.txt && rm azurefd.txt front_door_names.txt frontdoor_results.txt
	  sed -i 's/^/Azure Front Door\t/' final_frontdoor_results.txt
	  cat final_frontdoor_results.txt >> final_results.txt && rm final_frontdoor_results.txt
    else
      rm azurefd.txt front_door_names.txt
  fi

  if [ -s "azurewebsites.txt" ]; then
    echo -e "\033[1;33mChecking Azure Web App Availability.\033[0m" && sleep 2
    access_token=$(az account get-access-token --resource https://management.azure.com | jq -r '.accessToken')
      sed -E -i "s/token = \"[^\"]+\"/token = \"$access_token\"/g" tools/WebApp/run.py
        python tools/WebApp/run.py

	  cat azurewebsites.txt | sed 's/ /\t/g' > tm1 && mv tm1 azurewebsites.txt
          dos2unix -q azurewebsites.txt webapp_results.txt
	  paste azurewebsites.txt <(cut -f2 webapp_results.txt) >> final_webapp_results.txt && rm azurewebsites.txt web_app_names.txt webapp_results.txt
	  sed -i 's/^/Azure Web App\t/' final_webapp_results.txt
	  cat final_webapp_results.txt >> final_results.txt && rm final_webapp_results.txt
    else
      rm azurewebsites.txt web_app_names.txt
  fi

  if [ -s "trafficmanager.txt" ]; then
    echo -e "\033[1;33mChecking Azure Traffic Manager Availability.\033[0m" && sleep 2
    az group create --name azure-tm-garry --location eastus
    access_token=$(az account get-access-token --resource https://management.azure.com | jq -r '.accessToken')
      sed -E -i "s/token = \"[^\"]+\"/token = \"$access_token\"/g" tools/TrafficManagerCreate/run.py
        python tools/TrafficManagerCreate/run.py

	  cat trafficmanager.txt | sed 's/ /\t/g' > tm5 && mv tm5 trafficmanager.txt
          dos2unix -q trafficmanager.txt trafficmanager_results.txt
	  paste trafficmanager.txt <(cut -f2 trafficmanager_results.txt) >> final_trafficmanager_results.txt && rm trafficmanager.txt trafficmanager_results.txt tm_profile_names.txt
	  sed -i 's/^/Azure Traffic Manager\t/' final_trafficmanager_results.txt
	  cat final_trafficmanager_results.txt >> final_results.txt && rm final_trafficmanager_results.txt
    az group delete --name azure-tm-garry --yes --no-wait
    else
      rm trafficmanager.txt tm_profile_names.txt
  fi


deactivate



  if [ -s "elasticbeanstalk.txt" ]; then
    echo -e "\033[1;33mChecking AWS ElasticBeansalk Availability.\033[0m" && sleep 2
    ./tools/ElasticBeanstalk/run.sh elasticbeanstalk_dns_list.txt

	  cat elasticbeanstalk.txt | sed 's/ /\t/g' > tm4 && mv tm4 elasticbeanstalk.txt
	  dos2unix -q elasticbeanstalk.txt elasticbeanstalk_results.txt
	  paste elasticbeanstalk.txt <(cut -f2 elasticbeanstalk_results.txt) >> final_elasticbeanstalk_results.txt && rm elasticbeanstalk.txt elasticbeanstalk_dns_list.txt elasticbeanstalk_results.txt
	  sed -i 's/^/AWS ElasticBeansalk\t/' final_elasticbeanstalk_results.txt
	  cat final_elasticbeanstalk_results.txt >> final_results.txt && rm final_elasticbeanstalk_results.txt
    else
      rm elasticbeanstalk.txt elasticbeanstalk_dns_list.txt
  fi


  if [ -s "github.txt" ]; then
    echo -e "\033[1;33mChecking Github Availability.\033[0m" && sleep 2
        python tools/Github/run.py

	  sed -i 's/^/Github\t/' github_results.txt
	  cat github_results.txt >> final_results.txt && rm github_results.txt github.txt
    else
      rm github.txt
  fi


  if [ -s "netlify.txt" ]; then
    echo -e "\033[1;33mChecking Netlify Availability.\033[0m" && sleep 2
        python tools/Netlify/run.py

	  sed -i 's/^/Netlify\t/' netlify_results.txt
	  cat netlify_results.txt >> final_results.txt && rm netlify_results.txt netlify.txt
    else
      rm netlify.txt
  fi

  if [ -s "bunny_list.txt" ]; then
    echo -e "\033[1;33mChecking Bunny CDN Availability.\033[0m" && sleep 2
       ./tools/bunny/run.sh

	  sed -i 's/^/Bunny CDN\t/' bunny_results.txt
	  cat bunny_results.txt >> final_results.txt && rm bunny_results.txt bunny_list.txt
    else
      rm bunny_list.txt
  fi

  if [ -s "vercel_list.txt" ]; then
    echo -e "\033[1;33mChecking vercel CDN Availability.\033[0m" && sleep 2
       ./tools/vercel/run.sh

	  sed -i 's/^/vercel CDN\t/' vercel_results.txt
	  cat vercel_results.txt >> final_results.txt && rm vercel_results.txt vercel_list.txt
    else
      rm vercel_list.txt
  fi
    
rm $1
