#!/bin/bash

if [ -z $1 ]
        then
            echo "USAGE: $0 [list.txt] "
            exit
        else

domain_list=$1

for domain in $(cat $domain_list)
do

sh "$pwd"tools/c99.sh $domain
sh "$pwd"tools/subfinder.sh $domain
sh "$pwd"tools/assetfinder.sh $domain
sh "$pwd"tools/rapiddns.sh $domain
sh "$pwd"tools/securitytrails.sh $domain
sh "$pwd"tools/web.archive.sh $domain
#sh "$pwd"tools/chaos.sh $domain
#sh "$pwd"tools/amass.sh $domain
sh "$pwd"tools/urlscan.sh $domain
sh "$pwd"tools/whoisxmlapi.sh $domain

done

fi
