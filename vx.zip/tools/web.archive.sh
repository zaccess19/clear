#!/bin/bash


if [ -z $1 ]
        then
                echo "USAGE: $0 [domain.com]"
                exit
        else
                domain=$1
                 
                curl --silent --insecure --tcp-fastopen --tcp-nodelay "http://web.archive.org/cdx/search/cdx?url=*.$domain/*&output=text&fl=original&collapse=urlkey" | sed -e 's_https*://__' -e "s/\/.*//" | cut -d: -f1 | sort -u >> .tmp/$domain.txt 
                
                subcnt=$(cat .tmp/$domain.txt | wc -l)
                echo "\e[32m[+]\e[0m Found \e[31m"[`printf "%05.0f" $subcnt`]" \e[0mSubdomain for \e[33m"$domain"\e[0m Using \e[32mweb.archive.org"
                cat .tmp/$domain.txt >> results/subdomain.txt && rm .tmp/$domain.txt 

fi

if [ $2 ]
then
echo "You supplied more than 2 arguments"
echo "USAGE: $0 [domain.com]"
fi
