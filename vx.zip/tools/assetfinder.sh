#!/bin/bash


if [ -z $1 ]
        then
                echo "USAGE: $0 [domain.com]"
                exit
        else
                domain=$1
                 
                assetfinder -subs-only $domain >> .tmp/$domain.txt
                
                subcnt=$(cat .tmp/$domain.txt | wc -l)
                echo "\e[32m[+]\e[m Found \e[31m"[`printf "%05.0f" $subcnt`]" \e[mSubdomain for \e[33m"$domain"\e[m Using \e[32massetfinder"
                cat .tmp/$domain.txt >> results/subdomain.txt && rm .tmp/$domain.txt 

fi

if [ $2 ]
then
echo "You supplied more than 2 arguments"
echo "USAGE: $0 [domain.com]"
fi
