#!/bin/bash


if [ -z $1 ]
        then
                echo "USAGE: $0 [domain.com]"
                exit
        else
                domain=$1
                 
                curl --silent --insecure --tcp-fastopen --tcp-nodelay "https://subdomains.whoisxmlapi.com/api/v1?apiKey=at_u2jCYdLw9NB0GdqFe0FHsb6vzjFZ4&domainName=$domain" | grep -o -E "[a-zA-Z0-9._-]+\.$domain" | sort -u >> .tmp/$domain.txt
                
                subcnt=$(cat .tmp/$domain.txt | wc -l)
                echo "\e[32m[+]\e[m Found \e[31m"[`printf "%05.0f" $subcnt`]" \e[mSubdomain for \e[33m"$domain"\e[m Using \e[32mwhoisxmlapi"
                cat .tmp/$domain.txt >> results/subdomain.txt && rm .tmp/$domain.txt 

fi

if [ $2 ]
then
echo "You supplied more than 2 arguments"
echo "USAGE: $0 [domain.com]"
fi
