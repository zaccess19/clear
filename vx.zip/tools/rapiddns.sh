#!/bin/bash



if [ -z $1 ]
        then
                echo "USAGE: $0 [domain.com]"
                exit
        else
                domain=$1
		
                curl --silent --insecure --tcp-fastopen --tcp-nodelay "https://rapiddns.io/subdomain/$domain?full=1#result" | grep $domain | grep -oiE '([a-zA-Z0-9][a-zA-Z0-9-]{1,61}\.){1,}(\.?[a-zA-Z]{2,}){1,}' | sort -u >> .tmp/$domain.txt 
                
                subcnt=$(cat .tmp/$domain.txt | wc -l)
                echo "\e[32m[+]\e[0m Found \e[31m"[`printf "%05.0f" $subcnt`]" \e[0mSubdomain for \e[33m"$domain"\e[m Using \e[32mrapiddns.io\e[m"
                cat .tmp/$domain.txt >> results/subdomain.txt && rm .tmp/$domain.txt            
                

fi

if [ $2 ]
then
echo "You supplied more than 2 arguments"
echo "USAGE: $0 [domain.com]"
fi
