#!/bin/bash

	 
	Subdomain() {
	requestSub="$(curl -s --request GET \
		 --url https://api.securitytrails.com/v1/domain/$domain/subdomains \
		 --header 'APIKEY: ypA5ZshYbJC7SqrLb1D0gFCGgameyzY0' \
		 --header 'Accept: application/json')"
		 
			 echo $requestSub > .tmp/apiST.txt
			 cat .tmp/apiST.txt  | jq .subdomains | awk -v domain=$domain -F\" '{print $2 "." domain}' | sed '$d' | sed '1d'  > .tmp/$domain.txt
			 rm .tmp/apiST.txt
			 subcnt=$(cat .tmp/$domain.txt | wc -l)
			 echo "\e[32m[+]\e[0m Found \e[31m"[`printf "%05.0f" $subcnt`]" \e[0mSubdomain for \e[33m"$domain"\e[0m Using \e[32msecuritytrails.com"
			 cat .tmp/$domain.txt >> results/subdomain.txt && rm .tmp/$domain.txt 
	 		
}

if [ -z $1 ]
        then
                echo "USAGE: $0 [domain.com] "
                exit
        else
                domain=$1
                
fi

if [ -z $2 ]
then
Subdomain
fi
