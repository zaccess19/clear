#!/bin/bash

if [ -z $1 ]
        then
                echo "USAGE: $0 [domain.com]"
                exit
        else
                domain=$1
                
                curl --silent --insecure --tcp-fastopen --tcp-nodelay https://urlscan.io/api/v1/search/?q=$domain | grep -o -E "[a-zA-Z0-9._-]+\.$domain" | sort -u >> .tmp/$domain.txt 
                
                subcnt=$(cat .tmp/$domain.txt | wc -l)
                echo "\e[32m[+]\e[0m Found \e[31m"[`printf "%05.0f" $subcnt`]" \e[0mSubdomain for \e[33m"$domain"\e[0m Using \e[32murlscan.io"
                cat .tmp/$domain.txt >> results/subdomain.txt && rm .tmp/$domain.txt    

fi

if [ $2 ]
then
echo "You supplied more than 2 arguments"
echo "USAGE: $0 [domain.com]"
fi
