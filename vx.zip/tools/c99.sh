#!/bin/bash


if [ -z $1 ]
        then
                echo "USAGE: $0 [domain.com]"
                exit
        else
                domain=$1
                 
                curl --silent --insecure --tcp-fastopen --tcp-nodelay "https://api.c99.nl/subdomainfinder?key=TNXKM-Y25FY-8Y1IF-WJK9Y&domain=$domain" | sed 's#<br>#\n#g' | sort -u >> .tmp/$domain.txt
                
                subcnt=$(cat .tmp/$domain.txt | wc -l)
                echo "\e[32m[+]\e[m Found \e[31m"[`printf "%05.0f" $subcnt`]" \e[mSubdomain for \e[33m"$domain"\e[m Using \e[32mc99.nl"
                cat .tmp/$domain.txt >> results/subdomain.txt && rm .tmp/$domain.txt 

fi

if [ $2 ]
then
echo "You supplied more than 2 arguments"
echo "USAGE: $0 [domain.com]"
fi
